# Vert — Portrait Video Platform
**Product & Market Specification**
*Last updated: 6 June 2026*

---

## 1. Project Overview

Vert is a video-sharing platform built exclusively for **portrait/vertical ("vert") videos** — defined as any video shot in 9:16 portrait orientation. While TikTok, YouTube Shorts, and Instagram Reels support vertical video, none are built around it as their sole and defining format. Vert fills that gap with a YouTube-style experience — open channels, ad revenue sharing, and UGC — designed purely around this format.

---

## 2. Market Opportunity

### Vertical Video Is the Dominant Format

- Over 90% of mobile content is now created and consumed in portrait orientation. People hold their phones vertically 94–96% of the time, and fewer than 30% will rotate their device to watch horizontal video.
- Vertical video delivers roughly **2.5× higher engagement** than horizontal formats in comparable short-form contexts.
- Vertical video ad inventory commands **25–40% higher CPM rates** than standard display ads.
- CNN launched a dedicated vertical video feed in late 2025; publishers increasingly treat vertical as a first-class format, not a mobile afterthought.

### The Niche Is Validated but Not Owned

- No existing platform is **exclusively** built for vertical video. TikTok, YouTube Shorts, Instagram Reels, and Snapchat all support it — but as a feature, not an identity.
- The closest direct competitor is **Vurt** (myvurt.com), a mobile-first vertical streaming platform for indie filmmakers, launched March 2026. Vurt focuses on scripted micro-series using a curated content model — not open UGC or ad revenue sharing.
- The micro-drama segment (ReelShort, DramaBox) proves appetite for vertical-exclusive content at scale. ReelShort projected $1.2 billion in gross consumer spending in 2025; DramaBox reached $276 million. TikTok launched its own micro-drama app in January 2026.
- The short video platforms market is dominated by ad-based monetization (~75% of revenue) and mobile-first apps (~80% of market share in 2026) — both aligning directly with Vert's model.

### Market Size

- Global video streaming revenue is projected to grow from ~$191.6 billion in 2026 to over $865 billion by 2034 (~21% CAGR).
- Creator economy ad spend reached $29.5 billion in 2024 and is projected at $37 billion for 2025 — a 26% YoY increase, growing 4× faster than traditional media.

---

## 3. Competitive Landscape

| Platform | Vertical Video | UGC | Exclusive to Vertical | Open Channels | Ad Rev Share |
|---|---|---|---|---|---|
| TikTok | ✅ | ✅ | ❌ | ❌ | Partial |
| YouTube Shorts | ✅ | ✅ | ❌ | ✅ | ✅ (55/45) |
| Instagram Reels | ✅ | ✅ | ❌ | ❌ | Limited |
| Snapchat | ✅ | ✅ | ❌ | ❌ | Limited |
| Vurt | ✅ | ❌ (curated) | ✅ | ❌ | ❌ |
| **Vert (proposed)** | ✅ | ✅ | ✅ | ✅ | ✅ |

**Key differentiator:** Vert is the only platform combining exclusive vertical format + open UGC channels + ad revenue sharing. No direct clone competitor exists.

---

## 4. User Roles & Permissions

### Role Definitions

| Role | Description |
|---|---|
| Guest | Unauthenticated visitor. Can browse and watch videos. No account required. |
| Member | Registered user. Can interact with content and post videos. |
| Channel | Any member who has uploaded at least one video. Their profile becomes their channel. |
| Administrator | Platform staff. Can moderate content, manage channels, and review flagged content. |

### Permissions Matrix

| Feature | Guest | Member | Channel | Admin |
|---|---|---|---|---|
| Watch videos | ✅ | ✅ | ✅ | ✅ |
| Browse feed | ✅ | ✅ | ✅ | ✅ |
| View channel profiles | ✅ | ✅ | ✅ | ✅ |
| Share video link | ✅ | ✅ | ✅ | ✅ |
| Like / dislike | ❌ | ✅ | ✅ | ✅ |
| Comment | ❌ | ✅ | ✅ | ✅ |
| Flag video | ❌ | ✅ | ✅ | ✅ |
| Subscribe to channel | ❌ | ✅ | ✅ | ✅ |
| Upload video | ❌ | ✅ | ✅ | ✅ |
| Manage own channel | ❌ | ❌ | ✅ | ✅ |
| View revenue dashboard | ❌ | ❌ | ✅ | ✅ |
| Review flagged content | ❌ | ❌ | ❌ | ✅ |
| Suspend / remove channel | ❌ | ❌ | ❌ | ✅ |
| Remove any video | ❌ | ❌ | ❌ | ✅ |

---

## 5. Feature Specification

### 5.1 Video

- Only portrait/vertical (9:16) format videos are accepted. Videos in any other orientation are rejected at upload — no letterboxing or reformatting.
- Maximum file size: 500MB per upload (MVP).
- Maximum duration: 10 minutes per video (MVP).
- Supported formats: MP4, MOV. Other formats rejected with a clear error message.
- Videos are transcoded to HLS (adaptive bitrate) after upload. The video is not publicly visible until transcoding is confirmed complete.

### 5.2 User Accounts

- Account is optional for viewing and sharing.
- Account is required to post, comment, like, dislike, flag, and subscribe.
- Registration: email/password or Google OAuth. Apple sign-in on mobile.
- Email verification is required before a member can post or interact.

### 5.3 Video Feed & Discovery

- **Default feed (logged out):** Most recent uploads, globally — chronological.
- **Default feed (logged in):** Blended feed — recent uploads from subscribed channels (weighted) + platform-wide recent content (fill).
- **Channel page:** All videos from that channel, newest first.
- **Search:** Title and description full-text search. Results ordered by relevance, then recency.
- MVP excludes a recommendation algorithm. Algorithmic ranking is a post-launch feature.

### 5.4 Engagement

- **Likes and dislikes:** Thumbs up / thumbs down. One vote per user per video; switching is allowed. Counts are public.
- **Comments:** Text only. Threaded replies are a post-launch feature. Comments are visible to all; posting requires an account.
- **Sharing:** Any video has a shareable link accessible to guests. No in-app sharing/DMs at MVP.

### 5.5 Channels & Subscriptions

- Any member who uploads a video automatically has a channel. There is no separate "apply to be a creator" step.
- Channel profile includes: channel name, description, banner image, avatar, video list, subscriber count.
- Members can subscribe to any channel.
- Subscribers can opt in to email notifications for new uploads from that channel.

### 5.6 Content Moderation

- Any logged-in member can flag a video for inappropriate content. Guests cannot flag.
- Flag reasons (select one): Spam, Nudity or sexual content, Hate speech, Violent or graphic content, Misinformation, Other.
- Flagged videos remain live until reviewed by an admin (no auto-takedown at MVP).
- Admins can: remove a single video, suspend a channel (channel and videos hidden), or permanently delete a channel and all its videos.
- All admin actions are logged with timestamp, admin ID, target, action type, and reason.

### 5.7 Content Guidelines (Summary)

The following content is prohibited and subject to removal:

- Nudity, sexual content, or content sexualising minors
- Graphic violence or gore
- Hate speech targeting individuals or groups based on protected characteristics
- Harassment, threats, or doxxing
- Spam or artificially inflated engagement
- Content that violates applicable law

Full community guidelines will be published as a separate document before launch.

---

## 6. Business Model

### Monetization: Ad Revenue Sharing

- Platform earns revenue through video advertising (pre-roll, mid-roll, display).
- Ad revenue is shared with eligible content creators.
- Industry benchmark: YouTube's 55/45 split (creator/platform). Vert will adopt a milestone-based model:

| Creator Tier | Monthly Views (channel) | Creator Share |
|---|---|---|
| Starter | < 50,000 | Not eligible |
| Partner | 50,000 – 500,000 | 45% |
| Pro | 500,000 – 5M | 50% |
| Premium | 5M+ | 55% |

This structure allows the platform to cover infrastructure costs at early stages while offering a clear path to competitive payouts as channels grow.

### Creator Eligibility Requirements

To qualify for revenue sharing, a channel must meet all of the following:

- Minimum 500 subscribers
- Minimum 50,000 views in the past 30 days
- Account in good standing (no active strikes or suspensions)
- Verified payment method on file
- Content compliant with community guidelines

### Ad Network Strategy

- **MVP / Early stage:** Direct brand deals with vertical-video-friendly brands; specialist networks such as AdPlayer.Pro that maintain vertical video ad inventory.
- **Growth stage:** Google AdSense for video (requires platform scale and review approval).
- **Scale:** Programmatic inventory via multiple ad networks; brand sponsorship layer.

Note: New platforms cannot access Google AdSense video inventory immediately. Direct deals are the primary revenue path at launch and should be pursued ahead of any public launch.

### Revenue Benchmarks

- Average CPM in 2026: $3.50–$6.15 per 1,000 views (platform side).
- Highly engaged audiences: $8–$15 CPM.
- Vertical/short-form content earns lower CPMs than long-form but compensates with higher volume and engagement frequency.

### Indicative Revenue Scenarios

| Monthly Views | Avg CPM (platform) | Gross Revenue | Creator Payout (45%) | Platform Net |
|---|---|---|---|---|
| 1,000,000 | $4.00 | $4,000 | $1,800 | $2,200 |
| 5,000,000 | $4.50 | $22,500 | $10,125 | $12,375 |
| 20,000,000 | $5.00 | $100,000 | $50,000 | $50,000 |

These are illustrative projections. Actual CPM varies by niche, geography, and ad network relationships.

---

## 7. Platform Scope

- **Web:** Browser-based (desktop and mobile browser). Portrait-first layout.
- **Mobile App:** iOS and Android native apps.
- Mobile-first design is essential: the entire use case is portrait-mode content on a handheld device.

---

## 8. MVP Scope vs. Post-Launch

### Included in MVP

- User registration and authentication
- Video upload (portrait/9:16 only), transcoding, playback
- Feed (chronological), channel pages, search (title/description)
- Likes, dislikes, comments
- Channel subscriptions with optional email notifications
- Video flagging and admin moderation dashboard
- Basic channel/creator profile pages

### Excluded from MVP (Post-Launch)

- Algorithmic video recommendation feed
- Threaded comment replies
- In-app messaging or sharing
- Playlist creation
- Creator revenue dashboard and payouts
- Push notifications (mobile)
- Live streaming
- Video chapters or timestamps
- Clip or remix tools

---

## 9. Risks & Mitigations

| Risk | Notes | Mitigation |
|---|---|---|
| Content moderation at scale | UGC will attract inappropriate content | Build flagging dashboard before launch; publish clear guidelines; auto-flag keywords at scale |
| Storage and delivery costs | Video is expensive at scale | Enforce file size/duration limits at MVP; monitor delivery minutes weekly; build cost into monetization model |
| Creator acquisition | Empty platform won't attract viewers | Seed with invited creators pre-launch; curate initial content; offer early-partner terms |
| Ad network access | Google AdSense video unavailable to new platforms | Pursue direct brand deals first; use specialist vertical ad networks (AdPlayer.Pro) as bridge |
| Platform competition | Incumbents could add portrait-only modes at any time | Differentiation beyond format: open channels, rev share, creator community, dedicated UX |
| Regulatory exposure | User-generated content creates liability | DMCA takedown process, COPPA compliance, GDPR/privacy policy — required before launch |

---

## 10. Open Decisions

| # | Decision | Options | Status |
|---|---|---|---|
| 1 | AI build platform | Eric's tool vs. GLM 5.1 — run base code generation test on both | Pending |
| 2 | Video hosting provider | Cloudflare Stream (recommended for MVP) | Pending confirmation |
| 3 | Ad network for launch | AdPlayer.Pro + direct deals | Pending outreach |
| 4 | Creator revenue payout provider | Stripe Connect (recommended) | Pending |
| 5 | Full content guidelines document | Draft required before launch | Not started |
| 6 | DMCA / legal compliance | Legal review required | Not started |

---

*Sources: TechCrunch (Vurt launch, March 2026), AdPlayer.Pro Blog (vertical video 2026), Coherent Market Insights (short video platforms), Evadav (streaming market), Mux/Cloudflare Stream pricing data (Q2 2026), TubeAnalytics monetization report (2026), InfluenceFlow creator earnings data (2026).*
